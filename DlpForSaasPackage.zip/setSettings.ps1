﻿$settings = Get-Content .\settings.json | ConvertFrom-Json

$policyKey = "HKLM:\SOFTWARE\Policies\Google\Chrome\3rdparty\extensions\jhmbhhblimfofhkblileomhbafhlldpk\policy"
$safeStorageKey = "HKLM:\SOFTWARE\Policies\Google\Chrome\3rdparty\extensions\jhmbhhblimfofhkblileomhbafhlldpk\policy\SafeStorage"
$storagePolicySettingsKey = "HKLM:\SOFTWARE\Policies\Google\Chrome\3rdparty\extensions\jhmbhhblimfofhkblileomhbafhlldpk\policy\StoragePolicySettings"

Remove-Item -Path $policyKey -Force -Recurse
New-Item $safeStorageKey -Force
New-Item $storagePolicySettingsKey -Force

for (($i = 0); $i -lt $settings.Policy.SafeStorage.Count; $i++)
{
    $index = $i + 1
    Set-ItemProperty -Path $safeStorageKey -Name $index -Value $settings.Policy.SafeStorage.Get($i)
}

Set-ItemProperty -Path $storagePolicySettingsKey -Name "clipboard" -Value $settings.Policy.StoragePolicySettings.clipboard
Set-ItemProperty -Path $storagePolicySettingsKey -Name "screenCapture" -Value $settings.Policy.StoragePolicySettings.screenCapture
Set-ItemProperty -Path $storagePolicySettingsKey -Name "upload" -Value $settings.Policy.StoragePolicySettings.upload

