CREATE TABLE IF NOT EXISTS user_activity (
	"Id"	INTEGER UNIQUE,
	"UserId"	TEXT,
	"UserEmail"	TEXT,
	"TimeStamp"	TEXT NOT NULL,
	"ActionTaken"	TEXT NOT NULL,
	"Operation"	TEXT NOT NULL,
	PRIMARY KEY("Id" AUTOINCREMENT)
);

CREATE TABLE IF NOT EXISTS operation_clipboard_copy (
	"Id"	INTEGER UNIQUE,
	"Url"	TEXT NOT NULL,
	"Activity"	INTEGER NOT NULL,
	PRIMARY KEY("Id" AUTOINCREMENT),
	FOREIGN KEY("Activity") REFERENCES "user_activity"("Id") ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS operation_upload (
	"Id"	INTEGER UNIQUE,
	"Filename"	TEXT,
	"Url"	TEXT NOT NULL,
	"Activity"	INTEGER NOT NULL,
	PRIMARY KEY("Id" AUTOINCREMENT),
	FOREIGN KEY("Activity") REFERENCES "user_activity"("Id") ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS operation_screen_capture (
	"Id"	INTEGER UNIQUE,
	"Url"	TEXT NOT NULL,
	"Activity"	INTEGER NOT NULL,
	PRIMARY KEY("Id" AUTOINCREMENT),
	FOREIGN KEY("Activity") REFERENCES "user_activity"("Id") ON DELETE CASCADE
);

CREATE VIEW IF NOT EXISTS incident_logs AS
    SELECT UserId, UserEmail, TimeStamp, Operation, ActionTaken, Filename, Url
    FROM operation_upload JOIN user_activity on operation_upload.Activity = user_activity.Id
UNION
    SELECT UserId, UserEmail, TimeStamp, Operation, ActionTaken, NULL as Filename, Url
    FROM operation_clipboard_copy JOIN user_activity on operation_clipboard_copy.Activity = user_activity.Id
UNION
    SELECT UserId, UserEmail, TimeStamp, Operation, ActionTaken, NULL as Filename, Url
    FROM operation_screen_capture JOIN user_activity on operation_screen_capture.Activity = user_activity.Id
ORDER BY TimeStamp DESC;